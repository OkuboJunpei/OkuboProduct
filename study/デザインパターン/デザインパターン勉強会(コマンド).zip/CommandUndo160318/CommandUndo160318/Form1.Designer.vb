﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Add = New System.Windows.Forms.Button()
        Me.Subtract = New System.Windows.Forms.Button()
        Me.Undo = New System.Windows.Forms.Button()
        Me.Multiple = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'Add
        '
        Me.Add.Location = New System.Drawing.Point(12, 129)
        Me.Add.Name = "Add"
        Me.Add.Size = New System.Drawing.Size(112, 43)
        Me.Add.TabIndex = 0
        Me.Add.Text = "1を足す"
        Me.Add.UseVisualStyleBackColor = True
        '
        'Subtract
        '
        Me.Subtract.Location = New System.Drawing.Point(160, 129)
        Me.Subtract.Name = "Subtract"
        Me.Subtract.Size = New System.Drawing.Size(112, 43)
        Me.Subtract.TabIndex = 0
        Me.Subtract.Text = "1を引く"
        Me.Subtract.UseVisualStyleBackColor = True
        '
        'Undo
        '
        Me.Undo.Location = New System.Drawing.Point(12, 206)
        Me.Undo.Name = "Undo"
        Me.Undo.Size = New System.Drawing.Size(112, 43)
        Me.Undo.TabIndex = 0
        Me.Undo.Text = "もとに戻す"
        Me.Undo.UseVisualStyleBackColor = True
        '
        'Multiple
        '
        Me.Multiple.Location = New System.Drawing.Point(160, 206)
        Me.Multiple.Name = "Multiple"
        Me.Multiple.Size = New System.Drawing.Size(112, 43)
        Me.Multiple.TabIndex = 0
        Me.Multiple.Text = "2倍する"
        Me.Multiple.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("MS UI Gothic", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(38, 25)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(211, 55)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = "10"
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("MS UI Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 24
        Me.ListBox1.Location = New System.Drawing.Point(322, 31)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(238, 196)
        Me.ListBox1.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(633, 261)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Multiple)
        Me.Controls.Add(Me.Undo)
        Me.Controls.Add(Me.Subtract)
        Me.Controls.Add(Me.Add)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Add As System.Windows.Forms.Button
    Friend WithEvents Subtract As System.Windows.Forms.Button
    Friend WithEvents Undo As System.Windows.Forms.Button
    Friend WithEvents Multiple As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox

End Class

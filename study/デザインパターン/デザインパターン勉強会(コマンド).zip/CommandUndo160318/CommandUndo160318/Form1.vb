﻿
Public Class Form1
    ''' <summary>
    ''' 処理を実行するクラスのインスタンス
    ''' </summary>
    ''' <remarks></remarks>
    Private invoker As invoker
    ''' <summary>
    ''' ロード時の初期化処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub FormLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        invoker = New invoker(TextBox1, ListBox1)
    End Sub
    ''' <summary>
    ''' 足し算
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Add_Click(sender As Object, e As EventArgs) Handles Add.Click
        Dim calcObject As Add
        calcObject = New Add
        invoker._do(calcObject)
    End Sub
    ''' <summary>
    ''' 引き算
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Subtract_Click(sender As Object, e As EventArgs) Handles Subtract.Click
        Dim calcObject As Subtract
        calcObject = New Subtract
        invoker._do(calcObject)
    End Sub
    ''' <summary>
    ''' 掛け算
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Multiple_Click(sender As Object, e As EventArgs) Handles Multiple.Click
        Dim calcObject As Multiple
        calcObject = New Multiple
        invoker._do(calcObject)
    End Sub
    ''' <summary>
    ''' Undo
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Undo_Click(sender As Object, e As EventArgs) Handles Undo.Click
        invoker._undo()
    End Sub


End Class

Public MustInherit Class Calc
    ''' <summary>
    ''' Doインターフェース
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function _do(ByRef value As Integer) As String
    ''' <summary>
    ''' Undoインターフェース
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function _undo(ByRef value As Integer) As String
    ''' <summary>
    ''' 履歴に表示する文字列を返す
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function history() As String
End Class

Public Class Add
    Inherits Calc

    Public Overrides Function _do(ByRef value As Integer) As String
        Return value + 1
    End Function

    Public Overrides Function _undo(ByRef value As Integer) As String
        Return value - 1
    End Function

    Public Overrides Function history() As String
        Return "1足しました"
    End Function
End Class

Public Class Subtract
    Inherits Calc

    Public Overrides Function _do(ByRef value As Integer) As String
        Return value - 1
    End Function

    Public Overrides Function _undo(ByRef value As Integer) As String
        Return value + 1
    End Function

    Public Overrides Function history() As String
        Return "1引きました"
    End Function
End Class

Public Class Multiple
    Inherits Calc

    Public Overrides Function _do(ByRef value As Integer) As String
        Return value * 2
    End Function

    Public Overrides Function _undo(ByRef value As Integer) As String
        Return CInt(value / 2)
    End Function

    Public Overrides Function history() As String
        Return "2倍しました"
    End Function
End Class

Public Class invoker
    Private textBox As TextBox
    Private listBox As ListBox

    Private actionList As List(Of Calc)
    Private actionHistry As List(Of String)

    Public Sub New(ByRef _textBox As TextBox, ByRef _listBox As ListBox)
        'Commandインターフェースを持っているので、
        'Calcインターフェースを実装したものはこのリストで一元管理できる
        actionList = New List(Of Calc)
        actionHistry = New List(Of String)
        textBox = _textBox
        listBox = _listBox
    End Sub

    Public Sub _do(ByRef calcObject As Calc)
        Dim textBoxsValue As Integer
        textBoxsValue = CInt(textBox.Text)
        textBox.Text = calcObject._do(textBoxsValue)
        actionList.Add(calcObject)
        actionHistry.Add(calcObject.history)


        'リストボックスに履歴を書き込む
        WriteHistory()
    End Sub

    Public Sub _undo()
        If actionList Is Nothing OrElse actionList.Count = 0 Then
            Return
        End If
        Dim calcObject As Calc
        calcObject = actionList(actionList.Count - 1)

        Dim textBoxsValue As Integer
        textBoxsValue = CInt(textBox.Text)
        textBox.Text = calcObject._undo(textBoxsValue)
        actionList.RemoveAt(actionList.Count - 1)
        actionHistry.RemoveAt(actionHistry.Count - 1)

        'リストボックスに履歴を書き込む
        WriteHistory()
    End Sub

    Public Sub WriteHistory()
        listBox.Items.Clear()
        For i_histryIndex As Integer = 0 To actionHistry.Count - 1
            listBox.Items.Add(actionHistry(i_histryIndex))
        Next
        listBox.SelectedIndex = listBox.Items.Count - 1
    End Sub

End Class

